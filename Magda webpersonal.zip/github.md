repo: magda-negre/magda-negre
branch: main

## Last sync
date: 2026-07-29T13:54:13Z

### Updated in this project
- Web personal completa preparada para GitHub Pages (portada + tres secciones de escritos + arte).
- Contenido movido a `content.json`; la web lo lee al cargar.
- Modo edición con código y publicación directa al repositorio vía la API de GitHub.

## Screen map
| Pantalla | Archivos |
| --- | --- |
| Portada (bio, escritos, arte, contacto) | index.html, Portada.dc.html, site-data.js, content.json |
| Novelas | Novelas.dc.html, site-data.js, content.json |
| Cuentos | Cuentos.dc.html, site-data.js, content.json |
| Relatos de misterio | Misterio.dc.html, site-data.js, content.json |
